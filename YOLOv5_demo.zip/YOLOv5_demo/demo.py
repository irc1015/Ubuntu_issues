import argparse
from pathlib import Path
import os
import random
from shutil import copy

def parse_opt(known=False):
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', type=str , default='have_test', help='no_test/have_test')
    parser.add_argument('--path', type=str, default='/Users/zhuzhirui/Desktop/数据集/BDD100K', help='dataset path')
    parser.add_argument('--new_path', type=str, default='/Users/zhuzhirui/Desktop/BDD100K', help='new dataset path')
    parser.add_argument('--train_rate', type=float, default=0.7, help='train dataset rate')
    parser.add_argument('--val_rate', type=float, default=0.6, help='val dataset rate')
    parser.add_argument('--have_mask', default=True, help='whether objective detection or not')

    return parser.parse_known_args()[0] if known else parser.parse_args()
    #namespace, extra = parser.parse_known_args()


def handle(opt):
    mode = opt.mode
    path = str(opt.path)
    new_path = str(opt.new_path)
    train_rate = opt.train_rate
    have_mask = opt.have_mask

    if mode == 'have_test':
        val_rate = (1 - train_rate) * opt.val_rate

        os.makedirs(os.path.join(new_path, 'train'), exist_ok=True)
        os.makedirs(os.path.join(os.path.join(new_path, 'train'), 'image'), exist_ok=True)
        os.makedirs(os.path.join(os.path.join(new_path, 'train'), 'label'), exist_ok=True)

        os.makedirs(os.path.join(new_path, 'val'), exist_ok=True)
        os.makedirs(os.path.join(os.path.join(new_path, 'val'), 'image'), exist_ok=True)
        os.makedirs(os.path.join(os.path.join(new_path, 'val'), 'label'), exist_ok=True)

        os.makedirs(os.path.join(new_path, 'test'), exist_ok=True)
        os.makedirs(os.path.join(os.path.join(new_path, 'test'), 'image'), exist_ok=True)
        os.makedirs(os.path.join(os.path.join(new_path, 'test'), 'label'), exist_ok=True)

        image_path = Path(path + '/image')
        image = os.listdir(image_path)
        for i in range(len(image)):
            if image[]
        if image[0] == '.DS_Store':
            del image[0]
        print('original images are {}'.format(len(image)))

        if have_mask == True:
            label_path = Path(path + '/label')
            label = os.listdir(label_path)
            label.sort()
            if label[0] == 'DS_Store':
                del label[0]
            print('original labels are {}'.format(len(label)))

            for item in image:
                if item == '.DS_Store':
                    print('bad news')
            for item in label:
                if item == '.DS_Store':
                    print('bad news')

            merge = list(zip(image, label))
            random.shuffle(merge)
            image, label = zip(*merge)


            print('random original images are {}'.format(len(image)))
            print('random original labels are {}'.format(len(label)))

            train_len = int(len(image) * train_rate)
            print('train_len is {}'.format(train_len))

            train_image = image[:train_len]
            other_image = image[train_len:]
            train_label = label[:train_len]
            other_label = label[train_len:]
            print('before cpoy images are {}'.format(len(train_image)))
            print('before copy labels are {}'.format(len(train_label)))

            for i in range(train_len):
                copy(os.path.join(path + '/image', train_image[i]), os.path.join(new_path + '/train', 'image'))
                copy(os.path.join(path + '/label', train_label[i]), os.path.join(new_path + '/train', 'label'))

            new_image_list = os.listdir(os.path.join(new_path + '/train', 'image'))
            new_label_list = os.listdir(os.path.join(new_path + '/train', 'label'))
            print('after cpoy images are {}'.format(len(new_image_list)))
            print('after copy labels are {}'.format(len(new_label_list)))


    elif mode == 'no_test':
        val_rate = 1 - train_rate


if __name__ == '__main__':
    opt = parse_opt()
    handle(opt)