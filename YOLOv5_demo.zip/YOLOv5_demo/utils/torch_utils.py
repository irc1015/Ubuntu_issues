import os
import platform
import torch
from utils.general import LOGGER

def select_device(device='', batch_size=0, newline=True):
    #device is None/cpu/0
    device = str(device)
    s = f'YOLOv5 Python-{platform.python_version()} torch-{torch.__version__}'
    cpu = (device == 'cpu')
    if cpu:
        os.environ['CUDA_VISIBLE_DEVICES'] = '-1'
    elif device:
        os.environ['CUDA_VISIBLE_DEVICES'] = device
        assert torch.cuda.is_available() and torch.cuda.device_count() >= len(device.replace(',', '')), \
        f"Invalid CUDA '--device{device}' requested, use '--device cpu' or pass valid CUDA device(s)"
        #device.replace -> string
    if not cpu and torch.cuda.is_available():
        devices = device.split(',') if device else '0'
        n = len(devices)
        if n == 1:
            p = torch.cuda.get_device_properties(devices)
            s += f"CUDA:{devices} ({p.name}, {p.total_memory} MiB)\n"
        arg = 'cuda:0'
    else:#use CPU
        s += 'CPU\n'
        arg = 'cpu'

    if not newline:
        s = s.rstrip()

    LOGGER.info(s)
    return torch.device



