import inspect
import os
import sys
from pathlib import Path

print(__file__)
FILE = Path(__file__).resolve()
print(FILE)

ROOT = FILE.parents[0]
print(ROOT)

if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))

print(Path.cwd())

ROOT = Path(os.path.relpath(ROOT, Path.cwd()))
print(ROOT)

def hello():
    x = inspect.currentframe().f_back
    print(inspect.getframeinfo(x))
    print(inspect.getargvalues(x))