"""Train a YOLOv5 model on a custom dataset
pip install -r requirements.txt to install all tools YOLOv5 need
REMOVE:
utils.general.check_git_info, utils.general.check_git_status,
utils.general.check_requirements(in fact, ultralytics.utils.checks.check_requirements),

comet_ml
DDP Mode
"""


import argparse
import math
import os
import random
import subprocess
import sys
import time
from copy import deepcopy
from datetime import datetime
from pathlib import Path
import numpy as np
import torch
import torch.nn as nn
import yaml
from torch.optim import lr_scheduler
from tqdm import tqdm

from utils.general import (LOGGER, print_args, check_file, get_latest_run, check_yaml, increment_path, colorstr, yaml_save,
                           )
from utils.callbacks import Callbacks
from utils.torch_utils import (select_device)


FILE = Path(__file__).resolve()#get an absolute path of current py file
#/Users/zhuzhirui/PycharmProjects/YOLOv5_demo/train.py
ROOT = FILE.parents[0] #ROOT is the closest parent absolute path
#/Users/zhuzhirui/PycharmProjects/YOLOv5_demo

if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))

ROOT = Path(os.path.relpath(ROOT, Path.cwd()))
#Path.cwd() --> /Users/zhuzhirui/PycharmProjects/YOLOv5_demo
#os.path.relpath() return a relative filepath --> .

RANK = int(os.getenv('RANK', -1)) #RANK is -1
WORLD_SIZE = int(os.getenv('WORLD_SIZE', 1))




def parse_opt(known=False):
    parser = argparse.ArgumentParser()
    parser.add_argument('--weights', type=str, default=ROOT / 'yolov5s.pt', help='initial weights path')
    parser.add_argument('--cfg', type=str, default='', help='model.yaml path')
    parser.add_argument('--data', type=str, default=ROOT / 'data/coco128.yaml', help='dataset.yaml path')
    parser.add_argument('--hyp', type=str, default=ROOT / 'data/hyps/hyp.scratch-low.yaml', help='hyperparameters path')
    parser.add_argument('--epochs', type=int, default=100, help='total training epochs')
    parser.add_argument('--batch-size', type=int, default=16, help='total batch size for all GPUs, -1 for autobatch')
    parser.add_argument('--imgsz', '--img', '--img-size', type=int, default=640, help='train, val image size (pixels)')
    parser.add_argument('--rect', action='store_true', help='rectangular training')
    parser.add_argument('--resume', nargs='?', const=True, default=False, help='resume most recent training')
    parser.add_argument('--nosave', action='store_true', help='only save final checkpoint')
    parser.add_argument('--noval', action='store_true', help='only validate final epoch')
    parser.add_argument('--noautoanchor', action='store_true', help='disable AutoAnchor')
    parser.add_argument('--noplots', action='store_true', help='save no plot files')
    parser.add_argument('--evolve', type=int, nargs='?', const=300, help='evolve hyperparameters for x generations')
    parser.add_argument('--bucket', type=str, default='', help='gsutil bucket')
    parser.add_argument('--cache', type=str, nargs='?', const='ram', help='image --cache ram/disk')
    parser.add_argument('--image-weights', action='store_true', help='use weighted image selection for training')
    parser.add_argument('--device', default='', help='cuda device, i.e. 0 or 0,1,2,3 or cpu')
    parser.add_argument('--multi-scale', action='store_true', help='vary img-size +/- 50%%')
    parser.add_argument('--single-cls', action='store_true', help='train multi-class data as single-class')
    parser.add_argument('--optimizer', type=str, choices=['SGD', 'Adam', 'AdamW'], default='SGD', help='optimizer')
    parser.add_argument('--sync-bn', action='store_true', help='use SyncBatchNorm, only available in DDP mode')
    parser.add_argument('--workers', type=int, default=8, help='max dataloader workers (per RANK in DDP mode)')
    parser.add_argument('--project', default=ROOT / 'runs/train', help='save to project/name')
    parser.add_argument('--name', default='exp', help='save to project/name')
    parser.add_argument('--exist-ok', action='store_true', help='existing project/name ok, do not increment')
    parser.add_argument('--quad', action='store_true', help='quad dataloader')
    parser.add_argument('--cos-lr', action='store_true', help='cosine LR scheduler')
    parser.add_argument('--label-smoothing', type=float, default=0.0, help='Label smoothing epsilon')
    parser.add_argument('--patience', type=int, default=100, help='EarlyStopping patience (epochs without improvement)')
    parser.add_argument('--freeze', nargs='+', type=int, default=[0], help='Freeze layers: backbone=10, first3=0 1 2')
    parser.add_argument('--save-period', type=int, default=-1, help='Save checkpoint every x epochs (disabled if < 1)')
    parser.add_argument('--seed', type=int, default=0, help='Global training seed')
    parser.add_argument('--local_rank', type=int, default=-1, help='Automatic DDP Multi-GPU argument, do not modify')

    # Logger arguments
    parser.add_argument('--entity', default=None, help='Entity')
    parser.add_argument('--upload_dataset', nargs='?', const=True, default=False, help='Upload data, "val" option')
    parser.add_argument('--bbox_interval', type=int, default=-1, help='Set bounding-box image logging interval')
    parser.add_argument('--artifact_alias', type=str, default='latest', help='Version of dataset artifact to use')

    return parser.parse_known_args()[0] if known else parser.parse_args()
    #namespace, extra = parser.parse_known_args()

def train(hyp, opt, device, callbacks):#hyp.yaml
    save_dir = Path(opt.save_dir)
    epochs = opt.epochs
    batch_size = opt.batch_size
    weights = opt.weights
    single_cls = opt.single_cls
    evolve = opt.evolve
    data = opt.data
    cfg = opt.cfg
    resume = opt.resume
    noval = opt.noval
    nosave = opt.nosave
    workers = opt.workers
    freeze = opt.freeze
    callbacks.run('on_pretrain_routine_start') #NO.1 stage

    #different directories
    w = save_dir / 'weights' #weights dir
    (w.parent if evolve else w).mkdir(parents=True, exist_ok=True)
    last = w / 'last.pt'
    best = w / 'best.pt'

    #Hyperparameters
    if isinstance(hyp, str):
        with open(hyp, errors='ignore') as f:
            hyp = yaml.safe_load(f)
    LOGGER.info(colorstr('hyperparameters: ') + ','.join(f'{k}={v}' for k,v in hyp.items()))
    opt.hyp = hyp.copy()#for saving hyps to checkpoints

    #save run settings
    if not evolve:
        yaml_save(save_dir / 'hyp.yaml', hyp)
        yaml_save(save_dir / 'opt.yaml', vars(opt))



def main(opt, callbacks=Callbacks()):
    '''
    :param opt: namespace parameters
    :param callbacks: initial Callbacks into callbacks
    :return:
    '''
    if RANK in {-1, 0}:
        print_args(vars(opt))#vars() return a dict

    #Resume from specified or most recent last .pt file
    if opt.resume and not opt.evolve:
        '''set resume training stage and not set evolve hyperparameters'''
        last = Path(check_file(opt.resume) if isinstance(opt.resume, str) else get_latest_run())
        #last is path of pt file which is used to begin resume
        opt_yaml = last.parent.parent / 'opt.yaml'
        if opt_yaml.is_file():
            with open(opt_yaml, errors='ignore') as f:
                d = yaml.safe_load(f)
        else:
            d = torch.load(last, map_location='cpu')['opt']
        opt = argparse.Namespace(**d)
        opt.cfg, opt.weights, opt.resume = '', str(last), True
        #cfg is model.yaml path, weights is initial weights file path, resume is re-begin
    else:
        opt.data = check_file(opt.data)
        opt.cfg = check_yaml(opt.cfg)
        opt.hyp = check_yaml(opt.hyp)
        opt.weights = str(opt.weights)
        opt.project = str(opt.project)

        assert len(opt.cfg) or len(opt.weights), 'either --cfg or --weights must be specified'
        if opt.evolve:
            if opt.project == str(ROOT / 'runs/train'):
                opt.project == str(ROOT / 'runs/evolve')
            opt.exist_ok, opt.resume = opt.resume, False
        if opt.name == 'cfg':
            opt.name = Path(opt.cfg).stem
        opt.save_dir = str(increment_path(Path(opt.project) / opt.name, exist_ok=opt.exist_ok))

    device = select_device(opt.device)

    #Train
    if not opt.evolve:
        train(opt.hyp, opt, device, callbacks)
    else:
        print('Coming Soon\n')

if __name__ == '__main__':
    opt = parse_opt()
    main(opt)