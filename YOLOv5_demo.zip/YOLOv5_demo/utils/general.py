
import contextlib
import glob
import inspect
import logging
import logging.config
import math
import os
import platform
import random
import re
import signal
import subprocess
import sys
import time
import urllib
from copy import deepcopy
from datetime import datetime
from itertools import repeat
from multiprocessing.pool import ThreadPool
from pathlib import Path
from subprocess import check_output
from tarfile import is_tarfile
from typing import Optional
from zipfile import ZipFile, is_zipfile

import cv2
import numpy as np
import pandas as pd
import pkg_resources as pkg
import torch
import torchvision
import yaml

FILE = Path(__file__).resolve()
#/Users/zhuzhirui/PycharmProjects/YOLOv5_demo/utils/general.py
ROOT = FILE.parents[1]
#/Users/zhuzhirui/PycharmProjects/YOLOv5_demo
RANK = int(os.getenv('RANK', -1))

#other setting
NUM_THREADS = min(8, max(1, os.cpu_count() - 1)) #multiprocessing threads
DATASETS_DIR = Path(os.getenv('YOLOv5_DATASETS_DIR', ROOT / 'datasets')) #global datasets directory
AUTOINSTALL = str(os.getenv('YOLOv5_AUTOINSTALL', True)).lower() == 'true'
VERBOSE = str(os.getenv('YOLOv5_VERBOSE', True)).lower() == 'true'
TQDM_BAR_FORMAT = '{l_bar}{bar:10}{r_bar}' #tqdm bar format
#delete FONT setting

torch.set_printoptions(linewidth=320, precision=5, profile='full') # profile (default, short, full)
np.set_printoptions(linewidth=320, formatter={'float_kind': '{:11.5g}'.format})
pd.options.display.max_columns = 10
cv2.setNumThreads(0) #prevent OpenCV from multithreading (incompatible with PyTorch DataLoader)

os.environ['NUMEXPR_MAX_THREADS'] = str(NUM_THREADS)
os.environ['OMP_NUM_THREADS'] = '1' if platform.system() == 'darwin' else str(NUM_THREADS)
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2' #suppress verbose TF compiler warnings in Colab

LOGGING_NAME = 'yolov5'


def print_args(args: Optional[dict] = None, show_file = True, show_func = False):
    x = inspect.currentframe().f_back
    #who call this function -> train.py information
    file, _, func, _, _ = inspect.getframeinfo(x)
    #(filename, line_number, function_name, lines, index)
    if args is None:
        args, _, _, frm = inspect.getargvalues(x)
        args = {k: v for k, v in frm.items() if k in args}
    try:
        file = Path(file).resolve().relative_to(ROOT).with_suffix('') #minus file last suffix
    except ValueError:
        file = Path(file).stem #as same as with_suffix
    s = (f'{file}: ' if show_file else '') + (f'{func}: ' if show_func else '')
    LOGGER.info(colorstr(s) + ', '.join(f'{k}={v}' for k, v in args.items()))

def colorstr(*input):
    # Colors a string https://en.wikipedia.org/wiki/ANSI_escape_code, i.e.  colorstr('blue', 'hello world')
    *args, string = input if len(input) > 1 else ('blue', 'bold', input[0])  # color arguments, string
    colors = {
        'black': '\033[30m',  # basic colors
        'red': '\033[31m',
        'green': '\033[32m',
        'yellow': '\033[33m',
        'blue': '\033[34m',
        'magenta': '\033[35m',
        'cyan': '\033[36m',
        'white': '\033[37m',
        'bright_black': '\033[90m',  # bright colors
        'bright_red': '\033[91m',
        'bright_green': '\033[92m',
        'bright_yellow': '\033[93m',
        'bright_blue': '\033[94m',
        'bright_magenta': '\033[95m',
        'bright_cyan': '\033[96m',
        'bright_white': '\033[97m',
        'end': '\033[0m',  # misc
        'bold': '\033[1m',
        'underline': '\033[4m'}
    return ''.join(colors[x] for x in args) + f'{string}' + colors['end']

def check_suffix(file='yolov5s.pt', suffix=('.pt', ), msg=''):
    #Check files for acceptable suffix
    if file and suffix:
        if isinstance(suffix, str):
            suffix = [suffix]
        for f in file if isinstance(file, (list, tuple)) else [file]:
            s = Path(f).suffix.lower()
            if len(s):
                assert s in suffix, f'{msg}{f} acceptable suffix is {suffix}'

def check_file(file, suffix=''):
    #Search/Download file and return path
    check_suffix(file, suffix)
    file = str(file)
    if os.path.isfile(file): #file exist in right directory
        return file
    else:
        files = []
        for d in 'data', 'model', 'utils':
            files.extend(glob.glob(str(ROOT / d / '**'/ file), recursive=True))
        #search file in sub-directiory path
        assert len(files), f'File not found: {file}'
        assert len(files) == 1, f"Multiple files match '{file}', specify exact path: {files}"
        return files[0]

def get_latest_run(search_dir = '.'):
    #return path to most recent 'last.pt' in ./runs/ directory
    last_list = glob.glob(f'{search_dir}/**/last*.pt', recursive=True)
    return max(last_list, key=os.path.getctime) if last_list else ''

def check_yaml(file, suffix=('.yaml', '.yml')):
    return check_file(file, suffix)

def increment_path(path, exist_ok=False, sep='', mkdir=False):
    #Increment file or directory path with training
    path = Path(path)
    if path.exists() and not exist_ok: #path exist and no files in there
        path, suffix = (path.with_suffix(''), path.suffix) if path.is_file() else (path, '')

        for n in range(2, 9999):
            p = f'{path}{sep}{n}{suffix}'
            if not os.path.exists(p):
                break
        path = Path(p)

    if mkdir:
        path.mkdir(parents=True, exist_ok=True)

    return path

def set_logging(name=LOGGING_NAME, verbose=True):
    #sets up logging for the given name
    rank = int(os.getenv('RANK', -1))
    level = logging.INFO if verbose and rank in (-1, 0) else logging.ERROR
    logging.config.dictConfig({
        'version': 1,
        'disable_existing_loggers': False,
        'formatters': {
            name: {
                'format': '%(message)s'}},
        'handlers': {
            name: {
                'class': 'logging.StreamHandler',
                'formatter': name,
                'level': level, }},
        'loggers': {
            name: {
                'level': level,
                'handlers': [name],
                'propagate': False, }}
    })
set_logging(LOGGING_NAME)
LOGGER = logging.getLogger(LOGGING_NAME)

def yaml_save(file='data.yaml', data={}):
    with open(file, 'w') as f:
        yaml.safe_dump({k: str(v) if isinstance(v, Path) else v for k,v in data.items()}, f, sort_keys=False)


